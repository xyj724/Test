//
//  main.cpp
//  TwoSigma

#include <iostream>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <list>
#include <unordered_map>
#include <thread>
#include <map>
using namespace std;

//**********************************第一套题目***************************************************//
//*********************************************************************************************//

//------------------------NPR calculator OO design-----------------------
//画图写类
class Operation{
    public:
    virtual ~Operation(){delete this;}
    virtual float getResult(float f1,float f2)=0;
};

class Add : public Operation{
public:
    float getResult(float f1,float f2){
        return f1+f2;
    }
};

class Sub : public Operation{
public:
    float getResult(float f1,float f2){
        return f1-f2;
    }
};

class Mul : public Operation{
public:
    float getResult(float f1,float f2){
        return f1*f2;
    }
};

class Div : public Operation{
public:
    float getResult(float f1,float f2){
        return f1/f2;
    }
};

template <typename T> Operation * createInstance(){return new T;}

typedef map<string,Operation*(*)()> map_type;

map_type new_map;

class OperationFactory{
public:
    OperationFactory(){
        new_map["+"] = createInstance<Add>;
        new_map["-"] = createInstance<Sub>;
        new_map["*"] = createInstance<Mul>;
        new_map["/"] = createInstance<Div>;
    }
    
    float Calculate(float f1,float f2,string s){
        return new_map[s]()->getResult(f1,f2);
    }
};

class Tokens{
protected:
    string s;
    int index;
public:
    Tokens(string input){
        s = input;
        index = 0;
    }
    bool next(){
        while(s[index]==' ')index++;
        return index<s.length();
    }
    bool is_value(){
        return isdigit(s[index]);
    }
    char get_ch(){
        index++;
        return s[index-1];
    }
    float get_value(){
        int temp = index+1;
        while(s[temp]!=' ') temp++;
        float res = stof(s.substr(index,temp-index));
        index = temp+1;
        return res;
    }
};

class Calculator{
    public:
    Calculator(string s){ tk = new Tokens(s);}
    ~Calculator()   { delete tk;}
    
    float eval(){
        while(tk->next()){
            if(tk->is_value()){
                st.push(tk->get_value());
            }else{
                float f1,f2;
                if(!st.empty()){ f2 = st.top(); st.pop();}
                if(!st.empty()){ f1 = st.top(); st.pop();}
                st.push(calculate(f1, f2, tk->get_ch()));
            }
        }
        if(!st.empty()) return st.top();
        return 0;
    }
    
    float pop(){
        return 0;
    }
    
    float calculate(float f1,float f2, char op){
        OperationFactory *factory = new OperationFactory();
        return factory->Calculate(f1, f2, &op);
    }
    
    protected:
        stack<float> st;
        Tokens *tk;
};

//一个Array[Nodes]. Node包含［parent，value，valid］，给一个index，删除一个子树，然后更新这个valid，true表示还在，false表示删了，让我不能malloc空间，但是可以递归。
//要注意在test case里面，他有看size，所以每次删除了还要减一下size。还有如果删除的点是root的case
struct Nodes{
    int parentIndex;
    bool valid;
    bool visted;
};

void dfs(vector<Nodes> tree,int i){
    if(i==-1 || !tree[i].visted) {tree[i].valid = true; return;}
    if(tree[i].visted) return;
    dfs(tree,tree[i].parentIndex);
    tree[i].valid = tree[tree[i].parentIndex].valid;
}

void deleteNodes(vector<Nodes> tree,int index){
    //delete the nodes with the index and all it's subtree
    //way of deletion: set bool to false
    tree[index].visted = true;
    tree[index].valid = false;
    for(int i=0;i<tree.size();i++){
        if(tree[i].visted) continue;
        dfs(tree,i);
    }
}

//----------------------------wildcard matching-------------------------------

//然后问了client-server-database这种架构中，客户反映网站变慢。怎么确定是哪儿的问题。分三部分，客户端，服务器，数据库。
//http://www.lovemytool.com/blog/2009/01/chris_greer.html
//https://observer.viavisolutions.com/support/html_doc/current/index.html#page/apex/troubleshoot_network_server_app_issues.html


//**********************************第二套题目***************************************************//
//*********************************************************************************************//

//-----------------判断一个long n 是不是power of 4. 提出了bit manipulation 而且不准使用循环-------------------
//http://segmentfault.com/a/1190000003481153
//整除法
bool powerOfFour1(long num){
    if(num <= 0) return false;
    while(num % 4 == 0){
        num = num / 4;
    }
    return num == 1;
}

//位计数法
//1   0 0000 0001
//4   0 0000 0100
//16  0 0001 0000
//64  0 0100 0000
//256 1 0000 0000
//仔细观察可以发现，4的幂的二进制形式中，都是在从后向前的奇数位有一个1，所以只要一个数符合这个模式，就是4的幂。
bool powerOfFour2(long num){
    bool res = false;
    if(num <= 0) return res;
    for(int i = 1; i <= 64; i++){
        // 如果该位是0，则不操作
        if((num & 1) == 1){
            // 如果是偶数位为1，说明不是4的幂
            if(i % 2 == 0) return false;
            // 如果是奇数位为1，如果之前已经有1了，则也不是4的幂
            if(res){
                return false;
            } else {
                // 如果是第一次出现技术位为1，则可能是4的幂
                res = true;
            }
        }
        num = num >> 1;
    }
    return res;
}

//在Power of Two中，我们有一个解法是通过判断n & (n - 1)是否为0来判断是否为2的幂，因为4的幂肯定也是2的幂，所以这也可以用到这题来。那4的幂和2的幂有什么区别呢？根据上一个解法，我们知道4的幂的1只可能在奇数位，而2的幂的1可能在任意位，所以我们只要判断是不是奇数位是1就行了。因为根据n & (n - 1)我们已经筛出来那些只有1个1的数了，所以和010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101 也就是0x5555555555555555相与就能知道1是在奇数位还是偶数位了。
bool powerOfFour3(long num){
    return (num > 0) && ((num & (num - 1)) == 0) && ((num & 0x5555555555555555l) == num);
}

//给一个random number的generator的interator写interator 其中要求生成的随机数可以被五整除。
//完成你自己的hasnext()、next()
//随机数的iterator有getnext next. 是产生的随机数中是5的倍数
//iterator有三个methods，第三个remove()我觉得不需要删除underline collection然后我就直接在那个函数里throw Exception
//iterator要在next()中判断hasNext().因为作为一个iterator, 要调用next()不是非得先有hasNext().
class Iterator {
public:
    Iterator(const vector<int>& nums);
    Iterator(const Iterator& iter);
    virtual ~Iterator();
    // Returns the next element in the iteration.
    int next();
    // Returns true if the iteration has more elements.
    bool hasNext();
    void remove();
};

class ModFiveIterator : public Iterator {
    int res;
    bool flag;
public:
    int next() {
        hasNext();
        flag = false;
        return res;
    }
    
    bool hasNext()  {
        if(!flag){
            res = Iterator::next();
            while(Iterator::hasNext() && res%5)
                res = Iterator::next();
            flag = true;
            return !(res%5);
        }
        return true;
    }
    
};

//given two sets, mathmatical sets not binding to any programing languages, brain storm how all ways find the intersetion of the two sets
//http://segmentfault.com/a/1190000003836386


//----------------------text editor设计题-----------------
//insert(p), delete(p1, p2), highlight(p1, p2)，redo/undo, save/load update, search
//text editor需要insert，remove，highlight，需要想办法去index每次插入的object，原po说的interval tree应该就是index的方式吧。
//关键点在于text打算怎么存
//store highlight?
//他要求三天后再load这个text,需要可以undo三天前的操作. save的时候 保存成xml类型之类的 把之前的操作也一起存下来

struct textNode{
    string s;
    int index;
};

struct Operations{
    string op; //op
    string time;
};

class textEditor{
    list<textNode> l;
    unordered_map<int,textNode> mp; //tree is better
    stack<Operations> st;
};


//----------------------game of life--------------------------
void gameOfLife(vector<vector<int>>& board) {
    //use bit maniputation
    int row = board.size(), col = row?board[0].size():0;
    for(int i=0;i<row;++i)
        for(int j=0;j<col;++j){
            int count = 0;
            //go through it's neighbour
            for(int x=max(0,i-1);x<min(row,i+2);++x)
                for(int y=max(0,j-1);y<min(col,j+2);++y)
                    count+=board[x][y] & 1;
            if(count==3 || count-board[i][j]==3) board[i][j] |=2;
        }
    for(int i=0;i<row;++i)
        for(int j=0;j<col;++j)
            board[i][j]>>=1;
}

//In this question, we represent the board using a 2D array. In principle, the board is infinite, which would cause problems when the active area encroaches the border of the array. How would you address these problems?
//https://segmentfault.com/a/1190000003819277
//http://research.google.com/archive/mapreduce-osdi04-slides/index.html
//http://www.cnblogs.com/sharpxiajun/p/3151395.html


//给你两个independent queue，每个queue都存着timestamp，只能有getNext()来取queue里面的timestamp，每个timestamp只能被取一次，比较这两个queue里的timestamp，如果差值<1，print这两个timestamp。例如：
//Q1 0.2, 1.4, 3.0
//Q2 1.0 1.1, 3.5
//output: (0.2, 1.0), (1.4, 1.0), (0.2, 1.1), (1.4, 1.1), (3.0, 3.5)
//最后用了两个thread,两个thread-safe queue来实现. 每次call getNext(), 和另一个queue里存的每个item相比, 相差大于一就删除, 否则输出
//https://www.ibm.com/developerworks/cn/aix/library/au-multithreaded_structures1/

namespace concurrent {
    class Queue{
    private:
        vector<float> v;
        pthread_mutex_t _lock;
    public:
        Queue(){
            pthread_mutex_init(&_lock, NULL);
        }
        ~Queue(){
            pthread_mutex_destroy(&_lock);
        }
        void push(float f){
            pthread_mutex_trylock(&_lock);
            v.push_back(f);
            pthread_mutex_unlock(&_lock);
        }
        void pop(){
            pthread_mutex_trylock(&_lock);
            v.erase(v.begin());
            pthread_mutex_unlock(&_lock);
        }
    };
}

// Google Doc 这种多人同时编辑的，怎么让每个人看到的都是update的version
//http://stackoverflow.com/questions/5772879/how-do-you-write-a-real-time-webbased-collaboration-tool-such-as-google-docs

//--------------------Junit Test---------------------------------------
//https://code.google.com/p/guava-libraries/source/browse/guava-tests/test/com/google/common/collect/?r=9113082b77c6f80e0d4d80b24eb16bcee1a23a08


int main(int argc, const char * argv[]) {
}
